create user _REPLACE_WITH_USER_ identified by _REPLACE_WITH_PASSWD_;
grant connect to _REPLACE_WITH_USER_;
grant all privileges to _REPLACE_WITH_USER_;
